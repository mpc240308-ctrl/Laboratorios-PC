﻿
using System;
using System.Diagnostics.CodeAnalysis;
class Program
{
    //ejercicio 1
    static int Sumas(int num)
    {
        int Total = 0;
        while (num > 0)
        {
            Total = Total + num % 10;
            num /= 10;
        }
        return Total;
    }
    static int saldo(int sal, int retiro)
    {
        
        int Res = sal;
        if (sal >= retiro)
        {
            Res = sal - retiro;
        }
        else
        {
            Console.WriteLine("no se puede realizar");
        }
        return Res;
    }
    static double temperaturas(double temperaturaC)
    {
        double F = 0;
        F = ( (temperaturaC * (1.8)) + 32);
        return F;
    }
   
    static int sumarvida(ref int vida)
    {
        vida += 10;
        if (vida > 100)
        {
            vida = 100;
        }
        return vida;
    }

    static int quitarvida(ref int vida)
    {
        vida -= 7;
        if (vida < 0)
        {
            vida = 0;
        }
        return vida;
    }

    static string obtenerNivel(int puntos)
    {
        if (puntos >= 80)
        {
            return "Avanzado";
        }
        if (puntos >= 50)
        {
            return "Intermedio";
        }
        else
        {
            return "Básico";
        }
    }

    static string evaluarEstado(int puntos)
    {
        if (puntos == 100)
            return "Excelente";
        if (puntos >= 70)
            return "Aprobado";
        else
        return "Reprobado";
    }
    static void Main(string[] args)
        {
            //ejercicio 1
            int num;
            Console.WriteLine("ingrese un numero");
            num = Convert.ToInt32(Console.ReadLine());
        int resSuma = Sumas(num);
        Console.WriteLine("la suma de los digitos es " + resSuma);
        //ejercicio 2
        int sal, retiro;
        Console.WriteLine("ingresa el saldo");
        sal = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("ingresa el retiro");
        retiro = Convert.ToInt32(Console.ReadLine());
        int res = saldo(sal, retiro);
        Console.WriteLine("tu saldo restante es de "+res);
        //ejercicio 3
        double temperaturaC;
        Console.WriteLine("ingresa una temperatura: ");
        temperaturaC = Convert.ToDouble(Console.ReadLine());
        double temperaturaF = temperaturas(temperaturaC);
        Console.WriteLine("la temperatura en farenheith es " + temperaturaF);
        //ejercicio 4
        
        int puntosVida = 10;
        Console.WriteLine($"Puntos iniciales: {puntosVida}");

        
        Console.Write("¿Cuántas veces quieres curarte? (+10 de vida por pocion): ");
        int vecesCurar = Convert.ToInt32(Console.ReadLine());
        for (int i = 0; i < vecesCurar; i++)
        {
            sumarvida(ref puntosVida);
        }
        Console.WriteLine("Vida tras curarse "+puntosVida);

        Console.WriteLine("¡Has recibido 4 golpes! (-7 de vida por golpe)");
        for (int i = 0; i < 4; i++)
        {
            quitarvida(ref puntosVida);
        }
        Console.WriteLine("vida final "+ puntosVida);
        Console.WriteLine("Puntos finales: " + puntosVida);
        Console.WriteLine("Nivel: " + obtenerNivel(puntosVida));
        Console.WriteLine("Estado final: " + evaluarEstado(puntosVida));
    }
}




