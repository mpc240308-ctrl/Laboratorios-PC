﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        string palabra;
        char[] vector;
        Console.WriteLine("ingresa una palabra");
        palabra = Console.ReadLine();
        vector = palabra.ToCharArray();
        int n = vector.Length;
        bool Palindromo = true;
        for (int i = 0; i < n / 2; i++)
        {
            if (vector[i] != vector[n - i - 1])
            {
                Palindromo = false;
            }
        }
        if (Palindromo)
        {
            Console.WriteLine("es palindromo");
            Console.WriteLine(Palindromo);
        }
        else
        {
            Console.WriteLine("no es palindromo");
            Console.WriteLine(Palindromo);
        }

        string[] español = { "rojo", "azul", "amarillo", "blanco ", "verde" };
        string[] ingles = { "red", "blue", "yellow", "white ", "green" };
        string[] italiano = { "rosso", "blu", "giallo", "bianco", "verde" };
        string m;
        Console.WriteLine(" ingresa el color que deseas evaluar ");
        Console.WriteLine(" rojo.  azul. amarillo, blanco, verde ");

        bool seguir = true;
        while (seguir)
        {
            m = Console.ReadLine();
            switch (m)
            {
                case "rojo":
                    {
                        Console.WriteLine("colores");
                        Console.WriteLine(español[0]);
                        Console.WriteLine(ingles[0]);
                        Console.WriteLine(italiano[0]);
                        Console.WriteLine(" ingresa el color que deseas evaluar ");
                        break;
                    }
                case "azul":
                    {
                        Console.WriteLine("colores");
                        Console.WriteLine(español[1]);
                        Console.WriteLine(ingles[1]);
                        Console.WriteLine(italiano[1]);
                        Console.WriteLine(" ingresa el color que deseas evaluar ");
                        break;
                    }
                case "amarillo":
                    {
                        Console.WriteLine("colores");
                        Console.WriteLine(español[2]);
                        Console.WriteLine(ingles[2]);
                        Console.WriteLine(italiano[2]);
                        Console.WriteLine(" ingresa el color que deseas evaluar ");
                        break;
                    }
                case "blanco":
                    {
                        Console.WriteLine("colores");
                        Console.WriteLine(español[3]);
                        Console.WriteLine(ingles[3]);
                        Console.WriteLine(italiano[3]);
                        Console.WriteLine(" ingresa el color que deseas evaluar ");
                        break;
                    }
                case "verde":
                    {
                        Console.WriteLine("colores");
                        Console.WriteLine(español[4]);
                        Console.WriteLine(ingles[4]);
                        Console.WriteLine(italiano[4]);
                        Console.WriteLine(" ingresa el color que deseas evaluar ");
                        break;
                    }
                case "":
                    {
                        Console.WriteLine("saliendo...");
                        seguir = false;
                        break;
                    }
                default:
                    {
                        Console.WriteLine("palabra no disponible en leccion intente denuevo");
                        break;
                    }
            }
        }

        Random rnd = new Random();
        int[] calificaciones = new int[10];
        for (int i = 0; i < calificaciones.Length; i++)
        {
            calificaciones[i] = rnd.Next(50, 101);
        }

        bool ejecutar = true;
        while (ejecutar)
        {
            Console.WriteLine("       MENÚ PRINCIPAL         ");
            Console.WriteLine("1. Reporte de rendimiento");
            Console.WriteLine("2. Estadísticas");
            Console.WriteLine("3. Salir");

            int opcion = Convert.ToInt32(Console.ReadLine());
            switch (opcion)
            {
                case 1:
                    {
                        for (int j = 0; j < calificaciones.Length; j++)
                        {
                            int nota = calificaciones[j];
                            if (nota >= 50 && nota <= 64)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                            }
                            else if (nota >= 65 && nota <= 79)
                            {
                                Console.ForegroundColor = ConsoleColor.Yellow;
                            }
                            else if (nota >= 80 && nota <= 100)
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                            }
                            Console.WriteLine("tu nota es " + nota);
                            Console.ResetColor();
                        }
                        break;
                    }
                case 2:
                    {
                        double promedio = calificaciones.Average();
                        int calificacionMaxima = calificaciones.Max();
                        int calificacionMinima = calificaciones.Min();
                        Console.WriteLine("nota maxima " + calificacionMaxima);
                        Console.WriteLine("nota minima " + calificacionMinima);
                        Console.WriteLine("promedio " + promedio);
                        break;
                    }
                case 3:
                    {
                        ejecutar = false;
                        Console.WriteLine("finalizando");
                        break;
                    }
            }
        }

        string[] nombres = { "Ana", "Mario", "Saúl", "Karla", "María", "José" };
        double[] salarioXhora = { 100, 120.50, 98.65, 125, 132.50, 102.50 };
        double[] horasLaboradas = new double[6];
        Console.WriteLine("ingrese horas laboradas de cada trabajador");
        for (int i = 0; i < nombres.Length; i++)
        {
            Console.WriteLine("tabajador numero" + i +")" );
            horasLaboradas[i] = Convert.ToDouble(Console.ReadLine());
        }
        for (int i = 0; i < nombres.Length; i++)
        {
            double pagoSemanal;
            if (horasLaboradas[i] > 40)
            {
                double horasNormales = 40;
                double horasExtra = horasLaboradas[i] - 40;
                pagoSemanal = (horasNormales * salarioXhora[i]) + (horasExtra * salarioXhora[i] * 2);
            }
            else
            {
                pagoSemanal = horasLaboradas[i] * salarioXhora[i];
            }
            Console.WriteLine(nombres[i] + ": " + "Q" +pagoSemanal);
        }
    }
}