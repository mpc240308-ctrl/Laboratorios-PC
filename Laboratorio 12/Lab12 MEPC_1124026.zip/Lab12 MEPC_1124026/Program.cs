﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;

class Program
{
    static void Main(String[] args)
    {
        //ejercicio 1
        int[,] m = new int[5, 5];

        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                Console.WriteLine("ingresa un numero en la columna " + j + "fila" + i);
                m[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }

        int sumaSuperior = diagonalSuperior(m);
        int sumaSecundaria = diagonalSecundaria(m);

        Console.WriteLine("la suma de la diagonal principal es "+sumaSuperior);
        Console.WriteLine("la suma de la diagunal secundaria es"+sumaSecundaria);

        //ejercicio 2
        int[,] numeros = new int[4, 6];

        llenarnumeros(numeros);

        int numerospar = pares(numeros);
        int numerosimpares = impares(numeros);

        Console.WriteLine("la cantidad de numeros pares es "+numerospar);
        Console.WriteLine("la cantidad de numeros impares es "+numerosimpares);

        //ejercicio 3
        float[,] notas = new float[5, 4];

        llenarnotas(notas);

        float promedioFinal = promedio(notas);
        Console.WriteLine("el primedi del estudiante es: "+promedioFinal);

        bool aprobo = aprueba(promedioFinal);
        Console.WriteLine("el estudiante al final aprobo "+aprobo);

        //ejercicio 4
        int[,] simetrico = new int[3, 3];
        llenarcuadro(simetrico);

        bool Essimetrico = Simetricos(simetrico);
        Console.WriteLine("es simetrico es"+Essimetrico);
    }

    static int diagonalSuperior(int[,] m)
    {
        int suma = 0;
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (j > i)
                {
                    suma += m[i, j];
                }
            }
        }
        return suma;
    }

    static int diagonalSecundaria(int[,] m)
    {
        int suma = 0;
        for (int i = 0; i < 5; i++)
        {
            suma += m[i, 4 - i];
        }
        return suma;
    }

    static int pares(int[,] numeros)
    {
        int contador = 0;
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                if (numeros[i, j] % 2 == 0)
                {
                    contador++;
                }
            }
        }
        return contador;
    }

    static int impares(int[,] numeros)
    {
        int contador = 0;
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                if (numeros[i, j] % 2 != 0)
                {
                    contador++;
                }
            }
        }
        return contador;
    }

    static void llenarnumeros(int[,] numeros)
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                Console.WriteLine("ingresa un numero en la columna " + j + "fila" + i);
                numeros[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }
    }

    static void llenarnotas(float[,] notas)
    {
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                Console.WriteLine("ingresa un numero en la nota " + j + "estudiante" + i);
                notas[i, j] = float.Parse(Console.ReadLine());
            }
        }
    }

    static float promedio(float[,] notas)
    {
        float suma = 0;
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                suma += notas[i, j];
            }
        }
        return suma / 20;
    }

    static bool aprueba(float promedioFinal)
    {
        if (promedioFinal >= 61)
            return true;
        else
            return false;
    }

    static void llenarcuadro(int[,] cuadro)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                Console.WriteLine("ingresa un numero en la columna " + j + "fila" + i);
                cuadro[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }
    }

    static bool Simetricos(int[,] simetrico)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (simetrico[i, j] != simetrico[j, i])
                {
                    return false;
                }
            }
        }
        return true;
    }
}