﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab_13_MEPC_1124026
{
    public class Class1
    {
    }
        class Persona
        {
            public string nombre;
            public int edad;
            public double altura;
            public bool estudiante;

            public string nombrar()
            {
          
                return nombre;
            }
            public int edades()
            {
                return edad;
            }
            public double alturas()
            {
                return altura;
            }
            public bool Esestudiante()
            {
                return estudiante;
            }
        }
    }

