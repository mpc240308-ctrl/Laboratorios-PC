﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab_13_MEPC_1124026
{
    internal class Class2
    { 
    }
    class Vehiculo
    {
        public string marca;
        public string modelo;
        public int anio;
        public string color;
        public string placa;

        public string Lamarca()
        {
            return marca;
        }
        public string modeloV()
        {
            return modelo;
        }
        public int anios()
        {
            return anio;
        }
        public string colores()
        {
            return color;
        }
        public string placas()
        {
            return placa;
        }
    }
}
