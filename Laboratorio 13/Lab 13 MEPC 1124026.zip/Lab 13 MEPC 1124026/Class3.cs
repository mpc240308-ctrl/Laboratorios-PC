﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab_13_MEPC_1124026
{
    internal class Class3
    {
    }
    class Producto {
        public string codigo;
        public string nombres;
        public double precio;
        public int stock;
        public bool disponible;
        
        public string Elcodigo()
        {
            return codigo;
        }
        public string Elnombre()
        {
            return nombres;
        }
        public double Elprecio()
        {
            return precio;
        }
        public int ELstock()
        {
            return stock;
        }
        public bool Estadisponible()
        {
            return disponible;
        }
    }
}
