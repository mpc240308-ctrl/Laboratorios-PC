﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab_13_MEPC_1124026
{
    internal class Class4
    {
    } 
class Mascota
{
    public string nombres;
    public string especie;
    public int edad;
    public double peso;
    public bool vacuna;

    public string elnombre()
    {
        return nombres;
    }
    public string Laespecie()
    {
        return especie;
    }
    public int Laedad()
    {
        return edad;
    }
    public double Elpeso()
    {
        return peso;
    }
    public bool Estavacunado()
    {
        return vacuna;
    }
}
}

