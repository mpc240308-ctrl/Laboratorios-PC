﻿using Lab_13_MEPC_1124026;
using System;

class Program
{
    static void Main(string[] args)
    {
        Persona persona1 = new Persona();

        persona1.nombre = "Mario";
        persona1.edad = 20;
        persona1.altura = 1.75;
        persona1.estudiante = true;

        Console.WriteLine("Datos de la persona:");
        Console.WriteLine("Nombre: " + persona1.nombrar());
        Console.WriteLine("Edad: " + persona1.edades());
        Console.WriteLine("Altura: " + persona1.alturas());

        if (persona1.Esestudiante())
        {
            Console.WriteLine("Estado: Es estudiante.");
        }
        else
        {
            Console.WriteLine("Estado: No es estudiante.");
        }
        //ejericio 2
        Console.WriteLine(" ");

        Vehiculo carros = new Vehiculo();

        carros.modelo = "civic";
        carros.anio = 2015;
        carros.marca = "honda";
        carros.color = "gris";
        carros.placa = "LQZ778Q";
        
        Console.WriteLine("modelo del carro" +carros.modeloV());
        Console.WriteLine("anio  del carro" + carros.anios());
        Console.WriteLine("marca del carro" + carros.Lamarca());
        Console.WriteLine("modelo del carro" + carros.modeloV());
        Console.WriteLine("placa del carro" + carros.placas());

        //ejercicio 3
        Console.WriteLine(" ");

        int p;
        Console.WriteLine("escoge que producto escoger:");
        p = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("opcion 1 o opcion 2");
        Producto prod = new Producto();
        switch (p)
        {
            case 1:
                {
                    prod.nombres = "papas";
                    prod.precio = 15;
                    prod.disponible = true;
                    prod.codigo = "E4522";
                    Console.WriteLine("nombre del producto: "+ prod.Elnombre());
                    Console.WriteLine("precio del producto: " + prod.Elprecio());
                    Console.WriteLine("esta disponible del producto? " + prod.Estadisponible());
                    Console.WriteLine("codgido del producto: " + prod.Elcodigo());
                    break;
                }
                case 2:
                {
                    prod.nombres = "queso";
                    prod.precio = 30;
                    prod.disponible = false;
                    prod.codigo = "E5232";
                    Console.WriteLine("nombre del producto: " + prod.Elnombre());
                    Console.WriteLine("precio del producto: " + prod.Elprecio());
                    Console.WriteLine("esta disponible del producto? " + prod.Estadisponible());
                    Console.WriteLine("codgido del producto: " + prod.Elcodigo());
                    break;
                }
        }
        //ejercicio 4
        Console.WriteLine(" ");
        Mascota masc = new Mascota();

        masc.nombres = "cookie";
        masc.especie = "Puddle";
        masc.edad = 3;
        masc.peso = 40.12;
        masc.vacuna = true;

        Console.WriteLine("nombre de la mascota" + masc.elnombre());
        Console.WriteLine("la especie de la mascota" + masc.Laespecie());
        Console.WriteLine("la edad de la mascota" + masc.Laedad());
        Console.WriteLine("el peso de la mascota" + masc.Elpeso());
        Console.WriteLine("tiene sus vacunas de la mascota?" + masc.Estavacunado());
    }
}