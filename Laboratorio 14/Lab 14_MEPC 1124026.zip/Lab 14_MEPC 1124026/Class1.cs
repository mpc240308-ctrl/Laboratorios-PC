﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace Lab_14_MEPC_1124026
{
    internal class Class1
    {
    }
    class CuentaBancaria
    {
        public string titular;
        public string NumeroCuenta;
        public double saldo;
        public CuentaBancaria(string titular, string numeroCuenta, double saldo)
        {
            this.titular = titular;
            this.NumeroCuenta = numeroCuenta;
            this.saldo = 0;
        }
        public void Mostarinfo()
        {
            Console.WriteLine("INFO");
            Console.WriteLine("Titulo "+ this.titular);
            Console.WriteLine("Numero de cuenta " + this.NumeroCuenta);
            Console.WriteLine("saldo disponible " + this.saldo);
        }
        public void depositar(double monto)
        {
            this.saldo += monto;
        }
            public void Retirar(double monto)
        {
            if (saldo >= monto)
            {
                this.saldo = saldo - monto;
                Console.WriteLine("transaccion completada");

            }
            else {
                Console.WriteLine("no se puede completar la transaccion");
            }
        }
    }
}
