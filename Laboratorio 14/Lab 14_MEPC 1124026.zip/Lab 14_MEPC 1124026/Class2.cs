﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace Lab_14_MEPC_1124026
{
    internal class Class2
    {
    }
    public class Producto
    {
        public string Nombre;
        public double Precio;
        public int cantidad;
        public Producto(string Nombre, double Precio, int cantidad)
        {
            this.Nombre = Nombre;
            this.Precio = Precio;
            this.cantidad = cantidad;
        }
        public void Mostarinfo()
        {
            Console.WriteLine("INFO");
            Console.WriteLine("Nombre " + this.Nombre);
            Console.WriteLine("Precio " + this.Precio);
            Console.WriteLine("Cantidad " + this.cantidad);
        }
        public void vender(int CantVendido)
        {
            if (cantidad >= CantVendido)
            {
                this.cantidad = cantidad - CantVendido;
                Console.WriteLine("venta completada");
            }
            else
            {
                Console.WriteLine("no se puede vender");
            }
        }
        public void reabastecer(int CantComprada)
        {
            this.cantidad += CantComprada;
        }
    }
}
