﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Lab_14_MEPC_1124026
{
    internal class Class3
    {
    }
    class Estudiante
    {
        public string NombreEst;
        public int edad;
        public string grado;
        public  double[] notas;
        public double PromedioFinal;

    public Estudiante(string NombreEst, int edad, string grado, double[] notas)
        {
            this.NombreEst = NombreEst;
            this.edad = edad;
            this.grado = grado;
            this.notas = notas;
            
        }
    public void CalcularPromedio()
        {
            double suma = 0;
            for (int i = 0; i < this.notas.Length; i++)
            {
                suma += this.notas[i];
            }
            this.PromedioFinal = suma / this.notas.Length;
        }
    public void mostarInfo()
        {
            Console.WriteLine("INFO");
            Console.WriteLine("Nombre Estudiante" + this.NombreEst);
            Console.WriteLine("edad" + this.edad);
            Console.WriteLine("Grado" + this.grado);
            Console.WriteLine("notas" + this.notas);
            Console.WriteLine("Promedio obtenido: " + this.PromedioFinal);
        }
    public void Aprobar()
        {
            if ( this.PromedioFinal > 61)
            {
                Console.WriteLine("aprobado");
            }
            else
            {
                Console.WriteLine("reprobado");
            }
        }
            public void AgregarNota(double nuevaNota)
            {
            double[] nuevoArreglo = new double[this.notas.Length + 1];
            for (int i = 0; i < this.notas.Length; i++)
            {
                nuevoArreglo[i] = this.notas[i];
            }

            nuevoArreglo[this.notas.Length - 1] = nuevaNota;

            this.notas = nuevoArreglo;

            Console.WriteLine("nueva nota cambiada con exito");
        }
    }
}
