﻿using Lab_14_MEPC_1124026;
using System;
using System.Runtime.CompilerServices;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("ejercicio 1");
        Console.WriteLine("");

        CuentaBancaria Cuen = new CuentaBancaria("Mario Sanchez", "0213-4g21-413h", 325.00);
        CuentaBancaria Cuen1 = new CuentaBancaria("Juan Pablo", "024h-56th-098x", 325.00);
        Console.WriteLine("cuenta No.1: ");
        Console.WriteLine(Cuen.titular);
      
        Console.WriteLine("cuenta No.2: ");
        Console.WriteLine(Cuen1.titular);
        //mostarinfo
        Cuen.Mostarinfo();
       Cuen1.Mostarinfo();
        //depositar
        Cuen.depositar(500);
        Cuen1.depositar(640);
        //retirar
        Cuen.Retirar(240);
        Cuen.Retirar(123);
        //mostinfo
        Cuen.Mostarinfo();
        Cuen1.Mostarinfo();
        Console.WriteLine(" ");

        //ejercicio2
        Console.WriteLine("ejercicio 2");

        Producto prod = new Producto("papas", 12.50, 40);
        Producto prod1 = new Producto("pepsi", 7.50, 10);
        Console.WriteLine("producto No.1: ");
        Console.WriteLine(prod.Nombre);
        Console.WriteLine("producto No.2: ");
        Console.WriteLine(prod1.Nombre);
        //mostrarinfo
        prod.Mostarinfo();
        prod1.Mostarinfo();
        //venta
        prod.vender(30);
        prod1.vender(30);
        //reabastecer
        prod.reabastecer(10);
        prod1.reabastecer(10);
        Console.WriteLine("");

        Console.WriteLine("ejercicio 3");

        //ejercicio 3
        Estudiante est = new Estudiante("Mario", 16, "Tercero Basico", new double[] { 90.5, 92.2, 85.0 });
        Estudiante est1 = new Estudiante("Angel", 14, "primero Basico", new double[] { 90.50, 87.9, 91.5 });
        //promedio
        est.CalcularPromedio();
        Console.WriteLine("el promedio del estudiante 1 es : "+ est.PromedioFinal);
        est1.CalcularPromedio();
        Console.WriteLine("el promedio del estudiante 2 es : " + est1.PromedioFinal);
        //mostrar info
        est.mostarInfo();
        est1.mostarInfo();
        //aprobaron?
        est.Aprobar();
        est1.Aprobar();
        //nota nueva
        est.AgregarNota(80.45);
        est1.AgregarNota(65.45);
        
        //nuevo promedio 
        est.CalcularPromedio();
        Console.WriteLine("el promedio del estudiante 1 es : " + est.PromedioFinal);
        est1.CalcularPromedio();
        Console.WriteLine("el promedio del estudiante 2 es : " + est1.PromedioFinal);
        //resultados
        est.mostarInfo();
        est1.mostarInfo();
        Console.WriteLine("");
    }
}
