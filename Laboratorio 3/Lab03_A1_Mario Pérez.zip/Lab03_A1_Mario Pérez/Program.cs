﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab03_A1_Mario_Pérez
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingresa tu nombre: ");
            string nombre;
            nombre = Console.ReadLine();
            Console.WriteLine("Ingresa el curso : ");
            string curso;
            curso = Console.ReadLine();
            Console.WriteLine("hola " + nombre);
            Console.WriteLine("bienvenido al curso de " + curso);
            Console.WriteLine("Nunca te rindas ");
            Console.WriteLine("Presione cualquier tecla para finalizar...");
            Console.ReadKey();
        }
    }
}
