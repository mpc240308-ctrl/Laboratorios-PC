﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("ejercicio 1)");
        string nombre = "Mario";
        int nv = 15;
        float PuntosVida = 450.90f;
        bool jefe = true;

        Console.WriteLine("tu nombre es  " + nombre + " tu nivel es  " + nv + " tu vida es de " + PuntosVida + " ¿eres un jefe?" + jefe);
        //ejercicio 2
        Console.WriteLine("ejercicio 2)");
        int Numeroentero = 1500;
        long numeroLargo = Numeroentero;
        double numeroDecimal;
        numeroDecimal = Numeroentero;
        Console.WriteLine("el numero es " + numeroDecimal);
        //ejercicio 3
        Console.WriteLine("ejercicio 3)");
        double PrecioExacto = 45.89d;
        int PrecioRedondeado = (int)PrecioExacto;
        Console.WriteLine(PrecioExacto);
        Console.WriteLine(PrecioRedondeado);
        //ejercicio 4
        Console.WriteLine("ejercicio 4)");
        Console.WriteLine("ingresa un numero");
        String entradaUsuario = Console.ReadLine();
        int entero = int.Parse(entradaUsuario);
        int suma;
        suma = entero + 5;
        Console.WriteLine(suma);
        //ejercicio 5
        Console.WriteLine("ejercicio 5)");
        string valorBooleano = "true";
        Convert.ToBoolean(valorBooleano);
        string valordecimal = "25.5";
        Convert.ToDouble(valordecimal);
        Console.WriteLine(valorBooleano);
        Console.WriteLine(valordecimal);
        //ejercicio6
        Console.WriteLine("ejercicio 6)");
        double pi = 3.1415;
        pi.ToString("F2");
        Console.WriteLine(pi);
        //ejercicio 7
        Console.WriteLine("ejercicio 7)");
        Console.WriteLine("ingrese el precio del producto: ");
        String precio = Console.ReadLine();
        double precioent = double.Parse(precio);
        double iva = 0.21*precioent;
        double Total = iva+precioent;
        Console.WriteLine(Total);
        Console.WriteLine("presione una tecla para finalizar");
        Console.ReadKey();
    }
}
