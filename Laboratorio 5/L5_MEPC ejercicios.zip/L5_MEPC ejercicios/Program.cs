﻿using System;
using System.ComponentModel.Design;
using System.Runtime.InteropServices;
class Program
{
    static void Main()
    {
        int num;
        Console.WriteLine("ingresa un numero");
        num = Convert.ToInt32(Console.ReadLine());
        if (num == 0)
        {
            Console.WriteLine("el numero es igual a 0");
        }
        else
        {
            if (num > 0)
            {
                Console.WriteLine("el numero es positivo");
            }
            else
            {
                Console.WriteLine("el numero es negativo");
            }
        }
        //ejercicio 2
        int bis;
        Console.WriteLine("ingrese un annio");
        bis = Convert.ToInt32(Console.ReadLine());
        if ((bis % 4 == 0 && bis % 100 != 0) || (bis % 400 == 0))
        {
            Console.WriteLine("el annio es bisciesto");
        }
        else
        {
            Console.WriteLine("no es bisciesto");
        }
        //ejercicio 3
        int boleto = 0, multa = 0, ingresoMensual = 0;
        string pagoconmulta;
        Console.WriteLine("ingresa tu ingreso mensual Q");
        ingresoMensual = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("tienes multa (si/no) ?");
        pagoconmulta = Console.ReadLine();
        if (ingresoMensual >= 500 && ingresoMensual <= 1000) 
        {
            boleto = 10;
        }
        else if (ingresoMensual >= 1001 && ingresoMensual <= 3000)
        {
            boleto = 15;
        }
        else if (ingresoMensual >= 3001 && ingresoMensual <= 6000)
        {
            boleto = 50;
        }
        else if (ingresoMensual >= 6001 && ingresoMensual <= 9000)
        {
            boleto = 75;
        }
        else if (ingresoMensual >= 9001 && ingresoMensual <= 12000)
        {
            boleto = 100;
        }
        else if (ingresoMensual >= 12001)
        {
            boleto = 150;
        }
        if (pagoconmulta == "si")
        {
            multa = boleto * 2;
            Console.WriteLine("El pago total con multa es de: Q" + multa);
        }
        else
        {
            Console.WriteLine("El pago es de: Q" + boleto);
        }
        //ejercicio 4
        int horas = 0, PagoTotal = 0, Monto = 0, cambio = 0;
        int b100, b50, b20, b10, b5, b1;
        Console.WriteLine("ingrese el numero de horas estacionado");
        horas = Convert.ToInt32(Console.ReadLine());
        PagoTotal = horas * 10;
        Console.WriteLine("tu monto a pagar es de Q " + PagoTotal);
        Console.WriteLine("ingresa tu monto a pagar ");
        Monto = Convert.ToInt32(Console.ReadLine());
        if (Monto < PagoTotal)
        {
            Console.WriteLine("error pago incompleto");
        }
        else if (Monto > PagoTotal)
        {
            cambio = Monto - PagoTotal;
            Console.WriteLine("tu cambio es de Q" + cambio);
            b100 = cambio / 100;
            cambio = cambio % 100;
            b50 = cambio / 50;
            cambio = cambio % 50;
            b20 = cambio / 20;
            cambio = cambio % 20;
            b10 = cambio / 10;
            cambio = cambio % 10;
            b5 = cambio / 5;
            cambio = cambio % 5;
            b1 = cambio / 1;
            cambio = cambio % 1;
            Console.WriteLine("billetes de 100  " + b100);
            Console.WriteLine("billetes de 50  " + b50);
            Console.WriteLine("billetes de 20  " + b20);
            Console.WriteLine("billetes de 10  " + b10);
            Console.WriteLine("billetes de 5  " + b5);
            Console.WriteLine("billetes de 1  " + b1);
        }
        else
        {
            Console.WriteLine("el pago es exacto tenga feliz dia !");
        }
        Console.WriteLine("ingrese cualquier tecla para terminar el programa");
        Console.ReadKey();
    }
}