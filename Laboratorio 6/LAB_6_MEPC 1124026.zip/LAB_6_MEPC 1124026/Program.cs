﻿class Program {
    static void Main()
    {
        //ejercicio 1
        Console.WriteLine("ejercicio 1)");
        int  select,  temperatura;
        double kelvin, conversion;
        Console.WriteLine("ingresa tu conversion deseada");
        Console.WriteLine("1. De Celsius a Fahrenheit ");
        Console.WriteLine("2. De Fahrenheit a Celsius ");
        Console.WriteLine("3. De Celsius a Kelvin");
        Console.WriteLine("4 o cualquier otro numero mayor salida");

        select = Convert.ToInt32(Console.ReadLine());
        switch (select)
        {
            case 1:
                Console.WriteLine("ingresa tu temperatura que deseas convertir");
                temperatura = Convert.ToInt32(Console.ReadLine());
                conversion = ((1.8 * temperatura) + 32);
                Console.WriteLine("tu temperatura convertida es "+conversion +" Fahrenheit");
                break;
            case 2:
                Console.WriteLine("ingresa tu temperatura que deseas convertir");
                temperatura = Convert.ToInt32(Console.ReadLine());
                conversion = (0.56 * (temperatura - 32));
                Console.WriteLine("tu temperatura convertida es " + conversion + " Celsius");
                break;
            case 3:
                Console.WriteLine("ingresa tu temperatura que deseas convertir");
                kelvin = Convert.ToDouble(Console.ReadLine());
                conversion = (kelvin + 273.15);
                Console.WriteLine("tu temperatura convertida es " + conversion + " Kelvin");
                break;
            default:
                Console.WriteLine("salida");
                break;
        }
        //ejercicio 2
        Console.WriteLine("ejercicio 2)");
        int cliente;
        double productos;
        productos = 0;
        Console.WriteLine("ingrese la cantidad de productos");
        productos = Convert.ToDouble(Console.ReadLine());
        if (productos < 100.00) {
            Console.WriteLine("ingresa tu tipo de cliente");
            Console.WriteLine("1. regular ");
            Console.WriteLine("2. VIP ");
            cliente = Convert.ToInt32(Console.ReadLine());
            switch (cliente)
            {
                case 1:

                    Console.WriteLine("tu descuento es de 5%" );
                    break;
                case 2:
                    Console.WriteLine("tu descuento es de 10% " );
                    break;
                default:
                    Console.WriteLine("opcion invalida");
               
                    break;
            } 
        }
        else
        {
            Console.WriteLine("Eres mayorista");
            Console.WriteLine("tu descuento es de 15%");
        }
        //ejercicio 3
        Console.WriteLine("ejercicio 3)");
        int horas, pago;
        Console.WriteLine("ingresa la cantidad de horas que te estacionaste");
        horas = Convert.ToInt32(Console.ReadLine());
        if (horas <=2)
        {
            pago = horas * 5;
            Console.WriteLine("tu pago es " + pago + "$");
        }else if (horas < 2 && horas <= 5)
        {
            pago = horas * 4;
            Console.WriteLine("tu pago es " + pago +"$");
        } else if (horas > 5)
        {
            pago = horas * 3;
            Console.WriteLine("tu pago es " + pago + "$");
        }
        //ejercicio 4
        Console.WriteLine("ejercicio 4)");
        double puntuacion, bono;
        Console.WriteLine("ingresa tu puntuacion entre 0.0, 0.4 y 0.6 o más.");
        Console.WriteLine("advertencia cualquier puntuacion que no sea de las solicitadas es invalida");
        puntuacion = Convert.ToDouble(Console.ReadLine());
        if (puntuacion == 0.0)
        {
            bono = puntuacion * 2400;
            Console.WriteLine("tu puntuacion es Inaceptable");
            Console.WriteLine("tu bono es de " + bono + "euros");
        }
        else if (puntuacion == 0.4)
        {
            bono = puntuacion * 2400;
            Console.WriteLine("tu puntuacion es Aceptable");
            Console.WriteLine("tu bono es de " + bono +"euros");
        } else if (puntuacion >= 0.6)
        {
            bono = puntuacion * 2400;
            Console.WriteLine("tu puntuacion es Meritorio");
            Console.WriteLine("tu bono es de " + bono + "euros");
        } else
        {
            Console.WriteLine("puntuacion invalida");
        }
        Console.WriteLine("presione cualquier tecla para finalizar");
        Console.ReadKey();
    }
         }
