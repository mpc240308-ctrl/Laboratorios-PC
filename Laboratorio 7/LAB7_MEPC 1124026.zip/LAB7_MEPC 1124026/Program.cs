﻿using System;
using System.Reflection.Metadata;
class Program
{
    static void Main()
    {
        //programa 1
        Console.WriteLine("ejercicio 1");
        string nombre = "<Nombre completo>";
        int carnet = 1019126;
        int indice = 1;
        Console.WriteLine("Nombre" + nombre + "carnet" + carnet.ToString());
        while (indice <= 20)
        {
            if (indice % 2 == 0)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Green;

            }

            Console.WriteLine(indice);
            indice = indice + 1;

        }
        Console.ForegroundColor = ConsoleColor.White;
        Console.ReadLine();
        // ejercicio 2
        Console.WriteLine("ejercicio 2");
        int num, i = 1;
        Console.WriteLine("ingresa un numero positivo");
        num = Convert.ToInt32(Console.ReadLine());
        if (num > 0)
        {
            Console.WriteLine("numeros divisores de " + num);
            do
            {

                if (num % i == 0)
                {
                    Console.WriteLine(i);
                }
                i++;
            } while (i <= num);
        }
        else
        {
            Console.WriteLine("numero negativo");
        }
        //ejercicio 3
        Console.WriteLine("ejercicio 3");
        int contador, sig;
        int a = 0, b = 1;
        Console.WriteLine("ingrese hasta que numero de la serie de fibonacci desea");
        contador = Convert.ToInt32(Console.ReadLine());
        for (i = 0; i <= contador; i++)
        {
            Console.WriteLine(i + ") " + a);
            sig = a + b;
            a = b;
            b = sig;
        }
        //ejercicio 4 tablas de multiplicar
        Console.WriteLine("ejercicio 4");
        Console.WriteLine("tablas del 1 al 12");
        for (int tablas = 1; tablas <= 12; tablas++)
        {
            Console.WriteLine("");
            Console.WriteLine("tabla del "+tablas);
            Console.WriteLine("");
            for (i = 0; i <= 10; i++)
            {
                Console.WriteLine(i + " X " + tablas + " = " + tablas * i);
            }
        }
    }
}