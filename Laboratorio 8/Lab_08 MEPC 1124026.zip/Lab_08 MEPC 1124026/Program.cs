﻿using System;

class Program
{
    static void Main()
    {
        //ejercicio 1: 
        Console.WriteLine("mayor, menor, suma y promedio");
        int numero, suma = 0, mayor = 0, menor = 0;
        double promedio = 0;

        for (int i = 1; i <= 20; i++)
        {
            Console.WriteLine(i + ") Ingresa un numero: ");
            numero = Convert.ToInt32(Console.ReadLine());

            if (i == 1)
            {
                mayor = numero;
                menor = numero;
            } else if (numero > mayor)
            {
                mayor = numero;
            }
            else if (numero < menor)
            {
                menor = numero;
            }
            suma = suma + numero;
        }
        promedio = suma / 20.0;
        Console.WriteLine("el numero mayor es " + mayor);
        Console.WriteLine("el numero menor es " + menor);
        Console.WriteLine("la suma total es "+ suma);
        Console.WriteLine("el promedio es "+ promedio);
        // Ejercicio 2: Divisibilidad
        Console.WriteLine("ejercicio 2 numeros divisibles entre 5 y 2");

        for (int i = 0; i <= 100; i++)
        {
            if (i % 5 == 0 && i % 2 == 0)
            {
                Console.WriteLine(i + " el numero es divisible entre 5 y 2");
            }
            else if (i % 5 == 0)
            {
                Console.WriteLine(i + " el numero es divisible entre 5");
            }
            else if (i % 2 == 0)
            {
                Console.WriteLine(i + " el numero es divisible entre 2");
            }
            else
            {
                Console.WriteLine(i + " no es divisible entre ninguno");
            }
        }

        // Ejercicio 3: Registro de compras
        Console.WriteLine("ejercicio 3 Registro de compras");
        int cliente = 1;
        int o = 0;
        int monto;
        double total, desc, acumulado = 0;

        while (cliente <= 10)
        {
            Console.WriteLine("Numero de cliente: " + cliente);
            Console.WriteLine("Ingrese monto de compra");
            monto = Convert.ToInt32(Console.ReadLine());
            if (monto >= 300 && monto < 700)
            {
                Console.WriteLine(" ");
                Console.WriteLine("5% de descuento");
                desc = monto * 0.05;
                total = monto - desc;
                o++;
            }
            else if (monto >= 700)
            {
                Console.WriteLine(" ");
                Console.WriteLine("12% de descuento");
                desc = monto * 0.12;
                total = monto - desc;
                o++;
            }
            else
            {
                Console.WriteLine("feliz compra!! ");
                total = monto;

            }
            acumulado = total + acumulado;
            Console.WriteLine("Total pagado");
            Console.WriteLine(total);
            cliente++;
        }
        Console.WriteLine("clientes con descuento " + o);
        Console.WriteLine("total de ventas Q " + acumulado);
        //ejercicio 4
        Console.WriteLine("ejercicio 4 multiplos de 5 y 3 en numero decreciente");

        int n, p = 0;
        Console.WriteLine("Ingrese un numero: ");
        n = Convert.ToInt32(Console.ReadLine());
        while (p <= n)
        {
            if (n % 5 == 0)
            {
                Console.WriteLine(n + " es multiplo de 5");
            }
            else if (n % 3 == 0)
            {
                Console.WriteLine(n+ " es multiplo de 3");
            }
            else
            {
                Console.WriteLine(n + " no es multiplo de ninguno");
            }
            n--;
     
        }
        //ejercicio 5
        Console.WriteLine("ejercicio 5 filas de un triangulo");
        string t = "*";
        int filas;
        int u = 1;
        Console.WriteLine("Ingrese el número de filas para el triángulo:");
        filas = Convert.ToInt32(Console.ReadLine());
        while (u <= filas)
        {
            Console.WriteLine(t);
            t = t + "*";
            u++;
        }
    }
}
