﻿
using System;
class Program
{
    static void Main(string[] args)
    {
        //ejercicio 1
        Console.WriteLine("ejercicio 1");
        string palabra;
        Console.WriteLine("ingrese una palabra");
        palabra = Console.ReadLine();
        longitud(palabra);
        //ejercicio 2
        Console.WriteLine("ejercicio 2");
        int num1, num2;
        Console.WriteLine("ingrese un numero");
        num1 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("ingrese otro numero");
        num2 = Convert.ToInt32(Console.ReadLine());
        intercambio(ref num1, ref num2);
        //ejercicio 3
        Console.WriteLine("ejercicio 3");
        int M;
        double desc = 0.0, boleto = 10.0, precio = 0.0;
        Console.WriteLine("ingresa que eres para saber si tienes descuento (el precio del boleto es de Q10)");
        Console.WriteLine("1) niño, 2)adulto mayor 3)membresia premium, 4)adulto normal");
        M = Convert.ToInt32(Console.ReadLine());
        descuento(M, ref desc, ref boleto, precio);
        //ejercicio 4
        Console.WriteLine("ejercicio 4");
        int vida = 15;
        Console.WriteLine("inicio del juego tienes 15 de vida");
        golpe(ref vida);
        curar(ref vida);
        salud(ref vida);
        calificacion(ref vida);

    }
    static void longitud(string p)
    {
        Console.WriteLine(p.Length + " caracteres");
    }
    static void intercambio(ref int a, ref int b)
    {
        int intera = b;
        int interb = a;
        Console.WriteLine("numero 1 " + intera);
        Console.WriteLine("numero 2 " + interb);
    }

    static void descuento(int i, ref double d, ref double b, double p)
    {
        switch (i)
        {
            case 1:
                d = b * 0.50;
                p = b - d;
                Console.WriteLine("Descuento aplicado: 50% ser un niño");
                Console.WriteLine("tu pagas Q " + p);
                break;
            case 2:
                d = b * 0.15;
                p = b - d;
                Console.WriteLine("tu descuento es de 15% por ser adulto mayor");
                Console.WriteLine("tu pagas Q " + p);
                break;
            case 3:
                d = b * 0.9;
                p = b - d;
                Console.WriteLine("Descuento aplicado: 9% por tener membresia premium");
                Console.WriteLine("tu pagas Q " + p);

                break;
            default:
                p = b + d;
                Console.WriteLine("precio normal .");
                Console.WriteLine("tu pagas Q " + p);
                break;
        }
    }
    static void golpe(ref int c)
    {
        c = c - 5; 
        Console.WriteLine("has recibido un golpe Vida actual: " + c);
    }

    static void curar(ref int c)
    {
        c = c + 3; 
        Console.WriteLine("Te has curado. Vida actual: " + c);
    }

    static void salud(ref int c)
    {
        if (c >= 11 && c <= 15)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("vida Excelente");
        }
        else if (c >= 6 && c <= 10)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("vida Regular");
        }
        else if (c >= 0 && c <= 5)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("vida Crítica");
        }
        Console.ResetColor();
    }

    static void calificacion(ref int c)
    {
        Console.WriteLine("***clasificacion final***");
        if (c >= 15)
        {
            Console.WriteLine("Tu clasificación es: S");
        }
        else if (c >= 11 && c <= 15)
        {
            Console.WriteLine("Tu clasificación es: A");
        }
        else if (c >= 6 && c <= 10)
        {
            Console.WriteLine("Tu clasificación es: B");
        }
        else if (c >= 1 && c <= 5)
        {
            Console.WriteLine("Tu clasificación es: C");
        }
    }
}





